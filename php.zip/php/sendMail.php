<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Récupérer les données du formulaire
    $data = json_decode(file_get_contents("php://input"), true);

    // Valider les données
    $requiredFields = ['firstName', 'lastName', 'email', 'gender', 'job', 'birthDate', 'subject', 'message'];
    foreach ($requiredFields as $field) {
        if (empty($data[$field])) {
            echo json_encode(['status' => 'error', 'message' => 'Paramètres manquants: ' . $field]);
            exit();
        }
    }

    $firstName = $data['firstName'];
    $lastName = $data['lastName'];
    $email = $data['email'];
    $gender = $data['gender'];
    $job = $data['job'];
    $birthDate = $data['birthDate'];
    $subject = $data['subject'];
    $message = $data['message'];

    // Créer le contenu de l'email
    $to = 'ssilvacontact@gmail.com';  // Remplacez par votre adresse email de destination
    $subject = "Contact Form: $subject";
    $body = "Nom: $firstName $lastName\n";
    $body .= "Email: $email\n";
    $body .= "Genre: $gender\n";
    $body .= "Métier: $job\n";
    $body .= "Date de naissance: $birthDate\n";
    $body .= "Message:\n$message\n";

    // Headers de l'email
    $headers = "From: ssilvacontact@gmail.com\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "X-Mailer: PHP/" . phpversion();

    // Envoyer l'email
    if (mail($to, $subject, $body, $headers)) {
        echo json_encode(['status' => 'success', 'message' => 'Email envoyé avec succès.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Erreur lors de l\'envoi de l\'email.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Méthode non autorisée.']);
}
?>
