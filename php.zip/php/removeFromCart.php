<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

include 'config.php';

session_start();

$response = array('status' => 'error', 'message' => 'Unknown error');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        $response['message'] = 'User not logged in';
        echo json_encode($response);
        exit();
    }

    $data = json_decode(file_get_contents("php://input"), true);

    if (!isset($data['cart_id'])) {
        $response['message'] = 'Missing required parameters';
        echo json_encode($response);
        exit();
    }

    $cart_id = $conn->real_escape_string($data['cart_id']);

    $sql = "DELETE FROM cart WHERE id = '$cart_id' AND user_id = '" . $_SESSION['user_id'] . "'";

    if ($conn->query($sql) === TRUE) {
        $response['status'] = 'success';
        $response['message'] = 'Product removed from cart successfully';
    } else {
        $response['message'] = 'Error removing product from cart';
        $response['error'] = $conn->error;
    }

    $conn->close();
} else {
    $response['message'] = 'Invalid request method';
}

echo json_encode($response);
?>
