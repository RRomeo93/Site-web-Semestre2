<?php
include 'config.php';

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}


error_log("Session ID on profile update: " . session_id());
error_log("Session content on profile update: " . print_r($_SESSION, true));

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_SESSION['user_id'])) {
        error_log("User not logged in. Session content: " . print_r($_SESSION, true));
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit();
    }

    $userId = $_SESSION['user_id'];
    error_log("User ID from session: " . $userId);

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    error_log("Received name: " . $name);
    error_log("Received email: " . $email);
    error_log("Received password: " . $password);

    $sql = "UPDATE users SET username='$name', email='$email', password='$password' WHERE id='$userId'";

    error_log("SQL query: " . $sql);

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully']);
    } else {
        error_log("Error updating profile: " . $conn->error);
        echo json_encode(['status' => 'error', 'message' => 'Error updating profile: ' . $conn->error]);
    }

    $conn->close();
} else {
    error_log("Invalid request method: " . $_SERVER["REQUEST_METHOD"]);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
