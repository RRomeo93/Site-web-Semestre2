<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

include 'config.php';

$data = json_decode(file_get_contents("php://input"), true);

$name = $data['name'];
$category_id = $data['category_id'];
$image = $data['image'];
$description = $data['description'];
$seats = $data['seats'];
$transmission = $data['transmission'];
$price = $data['price'];
$stock = $data['stock'];

$sql = "INSERT INTO products (name, category_id, image, description, seats, transmission, price, stock) 
        VALUES ('$name', '$category_id', '$image', '$description', '$seats', '$transmission', '$price', '$stock')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(array("message" => "Product added successfully"));
} else {
    echo json_encode(array("message" => "Error: " . $sql . "<br>" . $conn->error));
}

$conn->close();
?>
