<?php
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Gérer les requêtes OPTIONS (pré-vol) pour CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

include 'config.php';


error_log("Session started. Session ID: " . session_id()); // Log pour vérifier le démarrage de la session
error_log("Session content: " . print_r($_SESSION, true)); // Log pour afficher le contenu de la session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    error_log("Received email: $email"); // Log pour vérifier l'email reçu
    error_log("Received password: $password"); // Log pour vérifier le mot de passe reçu

    $email = $conn->real_escape_string($email);
    
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        error_log("User found: " . print_r($user, true)); // Log pour vérifier l'utilisateur trouvé
        
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id']; // Stocker l'ID de l'utilisateur dans la session
            $_SESSION['is_admin'] = ($email === 'admin@admin.com'); // Stocker si l'utilisateur est admin
            error_log("User logged in. User ID: " . $user['id']); // Log pour vérifier l'enregistrement de l'ID
            error_log("Session ID after login: " . session_id()); // Log pour vérifier l'ID de session après connexion
            echo json_encode(['status' => 'success', 'message' => 'Login successful']);
        } else {
            error_log("Invalid password for user: $email"); // Log pour mot de passe invalide
            echo json_encode(['status' => 'error', 'message' => 'Invalid password']);
        }
    } else {
        error_log("No user found with email: $email"); // Log pour aucun utilisateur trouvé
        echo json_encode(['status' => 'error', 'message' => 'No user found with that email']);
    }

    $conn->close();
} else {
    error_log("Invalid request method: " . $_SERVER["REQUEST_METHOD"]); // Log pour vérifier la méthode de la requête
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
