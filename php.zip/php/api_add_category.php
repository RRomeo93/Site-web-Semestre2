<?php
// Handle CORS
header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    header('HTTP/1.1 200 OK');
    exit();
}

header('Content-Type: application/json');

include 'config.php';

// Capture the incoming data
$data = json_decode(file_get_contents("php://input"), true);

// Log to verify data
file_put_contents('php://stderr', print_r($data, TRUE));

// Validate input
if (isset($data['type']) && !empty($data['type'])) {
    $type = $data['type'];

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO categories (type) VALUES (?)");
    $stmt->bind_param("s", $type);

    // Execute the statement and check for errors
    if ($stmt->execute()) {
        echo json_encode(array("message" => "Category added successfully"));
    } else {
        echo json_encode(array("message" => "Error: " . $stmt->error));
    }

    // Close the statement
    $stmt->close();
} else {
    echo json_encode(array("message" => "Invalid input"));
    // Log invalid input
    file_put_contents('php://stderr', "Invalid input: " . print_r($data, TRUE));
}

// Close the database connection
$conn->close();
?>
