<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json');

include 'config.php';

// Vérifiez si une session est déjà démarrée avant d'appeler session_start()
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$response = array('status' => 'error', 'message' => 'Unknown error');

if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'User not logged in';
    echo json_encode($response);
    exit();
}

$user_id = $_SESSION['user_id'];

$sql = "SELECT cart.id AS cart_id, products.name, cart.quantity, products.price 
        FROM cart 
        JOIN products ON cart.product_id = products.id 
        WHERE cart.user_id = '$user_id'";

$result = $conn->query($sql);

$cartItems = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $cartItems[] = $row;
    }
    $response['status'] = 'success';
    $response['cartItems'] = $cartItems;
} else {
    $response['status'] = 'success';
    $response['cartItems'] = array();
}

$conn->close();
echo json_encode($response);
?>
