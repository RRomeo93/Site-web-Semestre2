<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header('Access-Control-Allow-Origin: http://localhost:3000');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    session_start();
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['status' => 'error', 'message' => 'User not logged in']);
        exit();
    }

    $data = json_decode(file_get_contents("php://input"), true);
    
    if (!isset($data['product_id']) || !isset($data['quantity'])) {
        echo json_encode(['status' => 'error', 'message' => 'Missing required parameters']);
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $product_id = $data['product_id'];
    $quantity = $data['quantity'];

    // Échapper les valeurs pour éviter les injections SQL
    $product_id = $conn->real_escape_string($product_id);
    $quantity = $conn->real_escape_string($quantity);

    $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES ('$user_id', '$product_id', '$quantity')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success', 'message' => 'Product added to cart successfully']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error adding product to cart', 'error' => $conn->error]);
    }

    $conn->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
}
?>
